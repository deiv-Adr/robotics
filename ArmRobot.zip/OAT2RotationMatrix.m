function R = OAT2RotationMatrix(phi1, theta, phi2)
    % Converts Z-Y-Z Euler angles to a rotation matrix
    % phi1: first rotation around Z-axis (in radians)
    % theta: rotation around Y-axis (in radians)
    % phi2: second rotation around Z-axis (in radians)
    phi1=deg2rad(phi1);
    theta=deg2rad(theta);
    phi2=deg2rad(phi2);
    % Rotation matrix around the Z-axis by phi1
    Rz1 = [cos(phi1), -sin(phi1), 0;
           sin(phi1), cos(phi1), 0;
           0, 0, 1];
    I = [0, 1, 0;0, 0, -1;-1, 0, 0];
    % Rotation matrix around the Y-axis by theta
    Ry = [cos(theta), 0, sin(theta);
          0, 1, 0;
          -sin(theta), 0, cos(theta)];

    % Rotation matrix around the Z-axis by phi2
    Rz2 = [cos(phi2), -sin(phi2), 0;
           sin(phi2), cos(phi2), 0;
           0, 0, 1];


    % Combine the rotations: R = Rz2 * I * Ry * Rz1
    R = Rz1 * I * Ry * Rz2
end
