P=[237.77;-177.73 ;-69.558];
JA=computeJA(P,0,0,-106.17)
rad2deg(JA)