P=[245;-177 ;-66];
JA=computeJA(P,0,0,-106)
rad2deg(JA)