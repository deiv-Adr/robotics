function [x,y,z] = RotationMatrixtoOAT(T)
    O = atan2(T(1,3),-T(2,3));
    
    % Roll (φ) around the x-axis
    %roll = atan2(T(3,2), T(3,3));
    A=atan2((-T(3,3)*cos(O)),(-T(2,3)));
    % Pitch (θ) around the y-axis
    %pitch = atan2(-T(3,1), sqrt(T(3,2)^2 + T(3,3)^2));
    T=atan2(T(3,2), -T(3,1));
    % Convert radians to degrees (optional, if you want the angles in degrees)
    x = rad2deg(O)
    y = rad2deg(A)
    z = rad2deg(T)


end