function Joint_angle= computeJA(X,O,A,T)
    % Define link offsets, link lengths, and link twists in numerical values
    d= [0*25.4, (79/16)*25.4, 0*25.4, 8*25.4, 0*25.4, 2.202*25.4];
    a= [0*25.4, 8*25.4, -5/16*25.4, 0*25.4, 0*25.4, 0*25.4];
    alpha= [-pi/2, 0, pi/2, -pi/2, pi/2, 0];
    R = OAT2RotationMatrix(O,A,T);

    %P4=P6-d6xa
    P=X-(d(6)*R(:,3))
    %w=sqrt(P(1)^2+P(2)^2-d(2)^2);
    theta=[deg2rad(-179.116), deg2rad(-143.553), deg2rad(-13.559),0,0,0];


    rR=sqrt((4*a(2)^2*a(3)^2+4*a(2)^2*d(4)^2)-(P(1)^2+P(2)^2+P(3)^2-a(2)^2-a(3)^2-d(2)^2-d(4)^2)^2)
    theta(1)=atan2(-abs((P(2))*(sqrt((P(1))^2+(P(2))^2-(d(2))^2))-(d(2))*P(1)),-abs((P(1))*(sqrt((P(1)^2)+(P(2))^2-(d(2))^2))+(d(2))*P(2)));
    %theta(1)=atan2(P(2),P(1));
    theta(3)=atan((2*a(2)*d(4)*(P(1)^2+P(2)^2+P(3)^2-a(2)^2-a(3)^2-d(2)^2-d(4)^2)-(2*a(2)*a(3)*rR))/(2*a(2)*d(4)*rR+2*a(2)*a(3)*(P(1)^2+P(2)^2+P(3)^2-a(2)^2-a(4)^2-d(2)^2-d(4)^2)))
    x=(-(P(3)*(a(2)+a(3)*cos(theta(3))+d(4)*sin(theta(3))))+(d(4)*cos(theta(3))-a(3)*sin(theta(3)))*sqrt(P(1)^2+P(2)^2-d(2)^2));
    y=(P(3)*(d(4)*cos(theta(3))-a(3)*sin(theta(3)))-(a(2)+a(3)*cos(theta(3))+d(4)*sin(theta(3)))*sqrt(P(1)^2+P(2)^2-d(2)^2));
    theta(2)=atan2(x,y)
    T = eye(3);
    for i = 1:3
        % Compute the transformation matrix for thi-177.73 s joint
        A = [cos(theta(i)), sin(theta(i))*-cos(alpha(i)), sin(theta(i))*sin(alpha(i));
         sin(theta(i)), cos(theta(i))*cos(alpha(i)), cos(theta(i))*-sin(alpha(i));
         0, sin(alpha(i)), cos(alpha(i))];
    
        % Multiply the transformation matrix to the total matrix
        T = T*A;
    end
    T=inv(T)*R
    theta(4)=atan2(T(2,3),T(1,3));
    theta(5)=atan2((cos(theta(4))*T(1,3)+sin(theta(4))*T(2,3)),T(3,3));
    theta(6)=atan2((-sin(theta(4))*T(1,1)+cos(theta(4))*T(2,1)),(-sin(theta(4))*T(1,2)+cos(theta(4))*T(2,2)));
    Joint_angle=theta;
end



