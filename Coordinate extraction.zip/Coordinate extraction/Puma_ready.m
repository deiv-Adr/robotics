function Puma_ready()
        % Define a set of target positions (Cartesian space)
    waypoints = [-90, -135.882, 5.334,180.002,49.457,-0.008];
    system('Puma_Speed 15');
    pause(2);
    % Loop through each waypoint and move the robot incrementally
    for i = 1:size(waypoints, 1)
        command = sprintf('Puma_MovetoJoints %.1f, %.1f, %.1f, %.1f, %.1f, %.1f', waypoints(i, :));
        system(command);
        pause(10);
    end
end
