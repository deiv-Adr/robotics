load("Calib_Results_stereo.mat");
load("Calib_Results_left.mat");
% Set the minimum area threshold to filter small objects
min_area_l = 8000;  % Adjust this based on your requirement
min_area_r= 9000;
Puma_ready;
T_hat = [ 0    -T(3)   T(2);
          T(3)   0    -T(1);
         -T(2)   T(1)   0 ];
F = inv(KK_right') * T_hat * R * inv(KK_left);

reachableObjects = []; % Initialize a matrix for reachable objects
while true
    captureImages();
    
    % Re-run object detection
    objet_l = uvdetectl('imgleft.jpg');
    objet_r = uvdetectr('imgright.jpg');
    if isempty(objet_l) || isempty(objet_r)
        break
    end
    % Filter objects based on area (ignore objects above threshold)
    valid_objects_left = objet_l(objet_l(:,4) <= min_area_l, :);
    valid_objects_right = objet_r(objet_r(:,4) <= min_area_r, :);
    % If no valid objects are detected, shake the box
    if isempty(valid_objects_left) || isempty(valid_objects_right)
        fprintf('No valid objects detected. Shaking the box.\n');
        Puma_shake();
        Puma_ready();
        continue; % Skip the rest of the loop and retry
    end
    %[valid_objects_left, valid_objects_right] = matchPointsEpipolar(F, valid_objects_left, valid_objects_right);
    
    centroid_l = valid_objects_left(:, 1:2);
    centroid_r = valid_objects_right(:, 1:2);
    % Apply the epipolar constraint to match points between left and right images
    XYZ=[];
    for i = 1:size(centroid_r, 1)
        XYZ = [XYZ;(reconstruct3D(centroid_l(i,1), centroid_l(i,2), centroid_r(i,1), centroid_r(i,2), KK_left, KK_right, R, T, Rc_1, Tc_left_1))'];
    end
    XYnotValid = [XYZ(:,1:2) zeros(size(XYZ, 1), 1) valid_objects_right(:,3)];
    XYthetaValid = [rearrange_points(XYnotValid)];
    
    if isempty(XYthetaValid)
        fprintf('No valid (reachable) objects found. Shaking the box again.\n');
        Puma_shake();
        Puma_ready();
        continue;
    end
    
    % If valid objects are found and reachable, proceed with grabbing
    for i = 1:size(XYthetaValid, 1)
        % Grab the object and perform other actions
        Puma_grab(XYthetaValid(i, :));
        Puma_ready();
        Puma_deliver();
        Puma_ready();
    end

end
fprintf('No more objects detect rsync 1 to roomba');