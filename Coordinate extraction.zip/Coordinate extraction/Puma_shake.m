function Puma_shake()
    % Define a set of target positions (Cartesian space)
    waypoints1 = [-90, -135.882, 5.334,180.002,49.457,-0.008];
    waypoints2 = [-51.999,-178.001,56.991,180.002,120.000,47.002];
    waypoints3= [-61,-178.001,56.991,180.002,120.000,47.002;
        -51.999,-178.001,56.991,180.002,120.000,47.002];
    % Loop through each waypoint and move the robot incrementally
    for i = 1:size(waypoints1, 1)
        command = sprintf('Puma_MovetoJoints %.1f, %.1f, %.1f, %.1f, %.1f, %.1f', waypoints1(i, :));
        system(command);
        pause(5);
    end
    system('openGripper');
    pause (1);
    for i = 1:size(waypoints2, 1)
        command = sprintf('Puma_MovetoJoints %.1f, %.1f, %.1f, %.1f, %.1f, %.1f', waypoints2(i, :));
        system(command);
        pause(3);
    end
    system('closeGripper');
    pause (1);
    system('Puma_Speed 20');
    for i = 1:size(waypoints3, 1)
        command = sprintf('Puma_MovetoJoints %.1f, %.1f, %.1f, %.1f, %.1f, %.1f', waypoints3(i, :));
        system(command);
        pause(1);
    end
    pause(2)
    system('openGripper');
    system('Puma_Speed 15');
    for i = 1:size(waypoints1, 1)
        command = sprintf('Puma_MovetoJoints %.1f, %.1f, %.1f, %.1f, %.1f, %.1f', waypoints1(i, :));
        system(command);
        pause(2);
    end
    
end