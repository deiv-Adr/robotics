function Puma_grab(XY,angle)
    
    system('openGripper');
    pause (1);
    waypoints=[XY,-46,180,90,angle+90;
        XY,-182.5,180,90,angle+90]
    for i = 1:size(waypoints, 1)
        command = sprintf('Puma_MovetoXYZOAT %.1f, %.1f, %.1f, %.1f, %.1f, %.1f', waypoints(i, :));
        system(command);
        pause(6);
    end
    system('closeGripper');
    pause (1);
    waypoints1=[XY,-46,180,90,angle+90];
    for i = 1:size(waypoints1, 1)
        command = sprintf('Puma_MovetoXYZOAT %.1f, %.1f, %.1f, %.1f, %.1f, %.1f', waypoints1(i, :));
        system(command);
        pause(5);
    end

end
